<?php 
      include_once('inc/admin-css.php');
?>

<?php
/**
 * Classic Editor
 *
 * Plugin Name: My Plugin
 * Plugin URI:  https://wordpress.org/plugins/classic-editor/
 * Description: Enables the WordPress classic editor and the old-style Edit Post screen with TinyMCE, Meta Boxes, etc. Supports the older plugins that extend this screen.
 * Version:     1.6.2
 * Author:      Md Shakib Hasan
 * Author URI:  https://github.com/WordPress/classic-editor/
 * License:     GPLv2 or later
 * License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: myplugin
 * Domain Path: /languages
 * Requires at least: 4.9
 * Tested up to: 5.8
 * Requires PHP: 5.2.4
 *
 * This program is free software; you can redistribute it and/or modify it under the terms of the GNU
 * General Public License version 2, as published by the Free Software Foundation. You may NOT assume
 * that you can use any other version of the GPL.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without
 * even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */
?>
<?php
//enqueue style && script

function myPlugin_style_scripts() {

    wp_enqueue_style( 'scriptnameone','https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'scriptnametwo','https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css', array(), '1.0.0', 'all' );

    wp_enqueue_style('style-css', plugins_url('/inc/style.css',__FILE__));
    wp_enqueue_style('my-css', plugins_url('/inc/dynamic.css',__FILE__));

    wp_enqueue_script( 'scriptthree','https://code.jquery.com/jquery-1.12.0.min.js', array(), '1.0.0', true );
    wp_enqueue_script( 'scriptfore','https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js', array(), '1.0.0', true );

    wp_enqueue_script('script-js', plugins_url('/inc/script.js',__FILE__), array(), '1.0.0', true);

}

add_action('wp_enqueue_scripts', 'myPlugin_style_scripts');


function load_custom_wp_admin_style(){

    wp_enqueue_style( 'custom_wp_admin_css', plugins_url('css/mystyle.css', __FILE__ ));
    wp_enqueue_style( 'wp-color-picker' );


    wp_enqueue_script( 'iris', admin_url( 'js/iris.min.js' ), array( 'jquery-ui-draggable', 'jquery-ui-slider', 'jquery-touch-punch' ), false, 1 );
    wp_enqueue_script( 'cp-active', plugins_url('/js/cp-active.js', __FILE__), array('jquery'), '', true );
    
}
    

add_action('admin_enqueue_scripts', 'load_custom_wp_admin_style');



//personal css_js
 
?>
<?php

// Register Custom Post Type
function myplugin_post_type() {

	$labels = array(
		'name'                  => _x( 'My PluginTypes', 'Post Type General Name', 'myplugin' ),
		'singular_name'         => _x( 'My Plugin Type', 'Post Type Singular Name', 'myplugin' ),
		'menu_name'             => __( 'My Plugin Types', 'myplugin' ),
		'name_admin_bar'        => __( 'Post Type', 'myplugin' ),
		'archives'              => __( 'Item Archives', 'myplugin' ),
		'attributes'            => __( 'Item Attributes', 'myplugin' ),
		'parent_item_colon'     => __( 'Parent Item:', 'myplugin' ),
		'all_items'             => __( 'All Items', 'myplugin' ),
		'add_new_item'          => __( 'Add New Item', 'myplugin' ),
		'add_new'               => __( 'Add New', 'myplugin' ),
		'new_item'              => __( 'New Item', 'myplugin' ),
		'edit_item'             => __( 'Edit Item', 'myplugin' ),
		'update_item'           => __( 'Update Item', 'myplugin' ),
		'view_item'             => __( 'View Item', 'myplugin' ),
		'view_items'            => __( 'View Items', 'myplugin' ),
		'search_items'          => __( 'Search Item', 'myplugin' ),
		'not_found'             => __( 'Not found', 'myplugin' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'myplugin' ),
		'featured_image'        => __( 'Featured Image', 'myplugin' ),
		'set_featured_image'    => __( 'Set featured image', 'myplugin' ),
		'remove_featured_image' => __( 'Remove featured image', 'myplugin' ),
		'use_featured_image'    => __( 'Use as featured image', 'myplugin' ),
		'insert_into_item'      => __( 'Insert into item', 'myplugin' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'myplugin' ),
		'items_list'            => __( 'Items list', 'myplugin' ),
		'items_list_navigation' => __( 'Items list navigation', 'myplugin' ),
		'filter_items_list'     => __( 'Filter items list', 'myplugin' ),
	);
	$args = array(
		'label'                 => __( 'My Plugin Type', 'myplugin' ),
		'description'           => __( 'My PluginType Description', 'myplugin' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'mypluginpost', $args );

}
add_action( 'init', 'myplugin_post_type', 0 );

?>

<?php
//https://bestjquery.com/tutorial/testimonial/demo61/

function myPluginContent(){ ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div id="testimonial-slider" class="owl-carousel">




    <?php // WP_Query arguments
$args = array(
	'post_type'              => array( 'mypluginpost' ),
	'post_status'            => array( 'publish' ),
    'posts_per_page'         => get_option('display_thime'),
);

// The Query
$myplugin = new WP_Query( $args );

// The Loop
if ( $myplugin->have_posts() ) {
	while ( $myplugin->have_posts() ) {
		$myplugin->the_post();?>


                <div class="testimonial">
                    <div class="pic">
                    <?php the_post_thumbnail();?>

                    </div>
                    <h3 class="title"><?php echo wp_trim_words(get_the_title(),3);?></h3>
                    <p class="description"><?php echo wp_trim_words(get_the_content(),10,'...');?></p>
                    <div class="testimonial-content">
                        <div class="testimonial-profile">
                            <h3 class="name"><?php echo get_post_meta( get_the_ID(), 'name', true );?></h3>
                            <span class="post"><?php echo get_post_meta( get_the_ID(), 'des', true );?></span>

                        </div>


                        <ul class="rating">
                            <?php
                            $rating = get_post_meta( get_the_ID(), 'reating', true );

                            if($rating == 1 ){ ?>
                            <li class="fa fa-star"></li>
                            <?php } else if($rating == 2){ ?>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>


                            <?php }else if($rating == 3){ ?>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>


                            <?php }else if($rating == 4){ ?>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>

                            <?php }else if($rating == 5){ ?>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>

                            <?php }else if($rating == 1.5){ ?>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star-half-empty"></li>
                                

                            <?php }else if($rating == 2.5){ ?>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star-half-empty"></li>
                                

                            <?php }else if($rating == 3.5){ ?>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star-half-empty"></li>
                                

                            <?php }else if($rating == 4.5){ ?>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star"></li>
                                <li class="fa fa-star-half-empty"></li>
                            <?php }
                            ?>


                        </ul>


                    </div>
                </div>     
		
	<?php
    }
} else {
	// no posts found
}

// Restore original Post Data
wp_reset_postdata();


?>
    </div>
        </div>
    </div>
</div>
     
<?php

}


?>


<?php
register_activation_hook(__FILE__, 'my_plugin_activate');
add_action('admin_init', 'my_plugin_redirect');

function my_plugin_activate() {
    add_option('activation_redirect', true);
}

// OR

//Solution 2 (@kaiser suggestion)
function my_plugin_redirect() {
    if (get_option('activation_redirect', false)) {
        delete_option('activation_redirect');
        if(!isset($_GET['activate-multi'])){
        
         wp_redirect("edit.php?post_type=mypluginpost&page=myplugin-settings-pages" );
        }
        
    }
}

?>
<?php
/**
 * Adds a submenu page under a custom post type parent.
 */
function myplugin_register_ref_page() {
    add_submenu_page(
        'edit.php?post_type=mypluginpost',
        __( 'Settings', 'myplugin' ),
        __( 'Settings', 'myplugin' ),
        'manage_options',
        'myplugin-settings-pages',
        'myplugin_settings_pages'
    );
}

add_action('admin_menu', 'myplugin_register_ref_page');
 
/**
 * Display callback for the submenu page.
 */
function myplugin_settings_pages() {
    ?>
    <div class="wrap">
        <div class ='action'>
        <h1>My Plugin Settings</h1>

        <div class ='left'>
        <h2>Settings</h2>
        <div>
            <form action ="options.php" method ='post'>
                <?php wp_nonce_field('update-options');?>
                <table>
                    <tr>
            <td><label for ="color_thime">Theme Color:</label></td>
            <td><input type ="text" name ='color_thime'value = '<?php echo get_option('color_thime');?>' class ='color-picker'></td>
            </tr>
            <tr>
            <td><label for ="color_hover">Hover Color:</label></td>
            <td><input type ="text" name ='color_hover'value = '<?php echo get_option('color_hover');?>'  class = 'color-picker' /></td>
            </tr>

            <tr>
            <td><label for ="color_text">Text Color:</label></td>
            <td><input type ="text" name ='color_text'value = '<?php echo get_option('color_text');?>'  class = 'color-picker' /></td>
            </tr>


            <tr>
            <td><label for ="display_thime">Post Per Page:</label></td>
            <td><input type ="number" name ='display_thime'value = '<?php echo get_option('display_thime');?>'/></td>
            </tr>

            <input type = "hidden" name ='action'value = 'update'/>
            <input type = "hidden" name ='page_options' value = color_thime,color_hover,color_text,display_thime />
            <tr><td></td>
            <td><input type = "submit" name ='submit' value = '<?php _e('Save-Changes','bwpt');?>'/></td>
            </tr>
            </table>

            </form>
    
         

        </div>

        </div>
        <div class ='right'>
        <h2>About Developer</h2>

        </div>
        </div>

    </div>
    <?php
   } ?>
