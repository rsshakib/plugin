
function myplugin_settings_pages() {
    ?>
    <div class="wrap">
        <div class ='action'>
        <h1>Testimonial Settings</h1>

        <div class ='left'>
        <h2>Settings</h2>
        <div>
            <form action ="options.php" method ='post'>
                <?php wp_nonce_field('update-options');?>
                <table>
                    <tr>
            <td><label for ="color_thime">Theme Color:</label></td>
            <td><input type ="text" name ='color_thime'value = '<?php echo get_option('color_thime');?>'required ='required' class ='color-picker'></td>
            </tr>
            <tr>
            <td><label for ="color_hover">Hover Color:</label></td>
            <td><input type ="text" name ='color_hover'value = '<?php echo get_option('color_hover');?>'  class = 'color-picker' /></td>
            </tr>
            <tr>
            <td><label for ="display_thime">Post Per Page:</label></td>
            <td><input type ="number" name ='display_thime'value = '<?php echo get_option('display_thime');?>'/></td>
            </tr>

            <input type = "hidden" name ='action'value = 'update'/>
            <input type = "hidden" name ='page_options' value = color_thime,color_hover,display_thime />
            <tr><td></td>
            <td><input type = "submit" name ='submit' value = '<?php _e('Save-Changes','bwpt');?>'/></td>
            </tr>
            </table>

            </form>
    
         

        </div>

        </div>
        <div class ='right'>
        <h2>About Developer</h2>

        </div>
        </div>

    </div>
    <?php
   } ?>
