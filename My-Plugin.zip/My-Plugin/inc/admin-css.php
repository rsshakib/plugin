      
      
    <style>

    .testimonial .title, .testimonial .post{
    <?php

    $color = get_option('color_thime');

    if($color){ ?>
        color: <?php echo $color; ?>
    <?php } else { ?>
        color: #eabd44;
    <?php } 
    ?>
    }


    .testimonial:hover .testimonial-content {  

    <?php
    $color2 = get_option('color_hover');
    if($color2){ ?>
   background : <?php echo $color2;?>
    <?php } else { ?>
        background: #1d3033; 
    <?php }
     ?>
    }

    .testimonial .description {
        font-weight:bold;
        <?php 
        $color3 = get_option('color_text');
        if($color3){ ?>
            color: <?php echo $color3; ?>
        <?php } else { ?> 
            color: #999;
        <?php } ?>
   

    }

            
    </style>