show this content : where show this post/content, There include this code/founction " myPluginContent()";

custom field : name, cauched this value <?php echo get_post_meta( get_the_ID(), 'name', true );?>
custom field : des, cauched this value <?php echo get_post_meta( get_the_ID(), 'des', true );?>
custom field : reating, cauched this value <?php echo get_post_meta( get_the_ID(), 'reating', true );?>